<?php 
include "headerfoter/headerfoter.php"
?>

<div class="container">
    <div class="row justify-content-center mt-5">
      <div class="col-md-6">
        <div class="card">
          <div class="card-body text-center">
            <h1 class="card-title">Thank You!</h1>
            <p class="card-text lead">Your response was successful.</p>
            <a href="registration.php" class="btn btn-primary">Back to Our Site</a>
          </div>
        </div>
      </div>
    </div>
  </div>

