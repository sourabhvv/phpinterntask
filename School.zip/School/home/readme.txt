registration.php is the index file

for student login try sourabhv945@gmail.com and password = 1234567

for admin login sourabh.cs1977@mitindore.co.in and password = 7654321