<?php
session_start();


if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = validateInput($_POST['name']);
    $rollno = validateInput($_POST['rollno']);
    $email = validateInput($_POST['email']);
    $contact = validateInput($_POST['contact']);
    $password = validateInput($_POST['password']);
    $class = validateInput($_POST['class']);

    $errors = [];

    if (empty($name)) {
        $errors['name'] = "Name is required";
    }
    if (empty($rollno)) {
        $errors['rollno'] = "Roll No is required";
    }
    if (empty($contact)) {
        $errors['contact'] = "Contact is required";
    }

    if (empty($email)) {
        $errors['email'] = "Email is required";
    } else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = "Invalid email format";
    } else {
        // Check if the email is already registered
        $dsn = 'mysql:host=localhost;dbname=school';
        $username = 'your_mysql_username';
        $passworddb = 'your_mysql_password';

        try {
            $pdo = new PDO($dsn, $username, $passworddb);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $stmt = $pdo->prepare("SELECT * FROM student WHERE email = :email");
            $stmt->bindParam(':email', $email);
            $stmt->execute();

            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user) {
                $errors['email'] = "Email is already registered";
            }
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }

        $pdo = null;
    }




    if (empty($password)) {
        $errors['password'] = "Password is required";
    }

    if (empty($class)) {
        $errors['class'] = "Class is required";
    }

    if (empty($errors)) {
        
        $dsn = 'mysql:host=localhost;dbname=school';
        $username = 'root';
        $passworddb = '';

        try {
          
            $pdo = new PDO($dsn, $username, $passworddb);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            
            $stmt = $pdo->prepare("INSERT INTO student (name, rollno, email, contact, password, class) VALUES (:name, :rollno, :email, :contact, :password, :class)");
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT); // Hash the password
            $stmt->bindParam(':name', $name);
            $stmt->bindParam(':rollno', $rollno);
            $stmt->bindParam(':email', $email);
            $stmt->bindParam(':contact', $contact);
            $stmt->bindParam(':password', $hashedPassword);
            $stmt->bindParam(':class', $class);
            $stmt->execute();

           
            header('location: success.php');
            exit();
        } catch (PDOException $e) {
            
            echo "Error: " . $e->getMessage();
        }

        $pdo = null;
    } else {
        $_SESSION['error'] = $errors;
        $_SESSION['input'] = $_POST;
        header('location: registration.php');
        exit();
    }
}

function validateInput($data)
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Registration Form</title>
</head>
<body style="background-image:url('headerfoter/anime_school.jpg')">

    <?php include 'headerfoter/headerfoter.php'; ?>
    
     <div class="container">
     <div id="intro" class="bg-image shadow-2-strong">
        <div class="mask d-flex align-items-center h-100vh" >
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-5 col-md-8">

                        <form class="bg-white rounded-5 shadow-5-strong p-5" action="registration.php" method="post">
                            <!-- Email input -->
                            <div class="form-outline mb-2">
                                <label for="">student registration</label>
                                <label class="form-label" for="name">Your Name</label>
                                <input type="text" id="name" class="form-control" name="name"
                                    value="<?php echo isset($_SESSION['input']['name']) ? $_SESSION['input']['name'] : ''; ?>" />
                                <?php if (isset($_SESSION['error']) && isset($_SESSION['error']['name'])): ?>
                                    <span style="color:red" ><?php echo $_SESSION['error']['name']; ?></span>
                                <?php endif; ?>
                            </div>

                            <div class="form-outline mb-2">
                                <label class="form-label" for="rollno">Roll No</label>
                                <input type="text" id="rollno" class="form-control" name="rollno"
                                    value="<?php echo isset($_SESSION['input']['rollno']) ? $_SESSION['input']['rollno'] : ''; ?>" />
                                <?php if (isset($_SESSION['error']) && isset($_SESSION['error']['rollno'])): ?>
                                    <span style="color:red" ><?php echo $_SESSION['error']['rollno']; ?></span>
                                <?php endif; ?>
                            </div>

                            
                            <div class="form-outline mb-2">
                                <label class="form-label" for="email">Your Email</label>
                                <input type="email" id="email" class="form-control" name="email"
                                    value="<?php echo isset($_SESSION['input']['email']) ? $_SESSION['input']['email'] : ''; ?>" />
                                <?php if (isset($_SESSION['error']) && isset($_SESSION['error']['email'])): ?>
                                    <span style="color:red" ><?php echo $_SESSION['error']['email']; ?></span>
                                <?php endif; ?>
                            </div>


                            <!-- Password input -->
                            <div class="form-outline mb-2">
                                <label class="form-label" for="contact">Contact No</label>
                                <input type="text" id="contact" class="form-control" name="contact"
                                    value="<?php echo isset($_SESSION['input']['contact']) ? $_SESSION['input']['contact'] : ''; ?>" />
                                <?php if (isset($_SESSION['error']) && isset($_SESSION['error']['contact'])): ?>
                                    <span style="color:red"><?php echo $_SESSION['error']['contact']; ?></span>
                                <?php endif; ?>
                            </div>

                            <div class="form-outline mb-2">
                                <label class="form-label" for="password">Password</label>
                                <input type="password" id="password" class="form-control" name="password" />
                                <?php if (isset($_SESSION['error']) && isset($_SESSION['error']['password'])): ?>
                                    <span style="color:red"><?php echo $_SESSION['error']['password']; ?></span>
                                <?php endif; ?>
                            </div>

                            <div class="form-outline mb-2">
                                <label class="form-label" for="class">Class</label>
                                <select name="class" id="class">
                                    <option value="8">8th</option>
                                    <option value="9">9th</option>
                                    <option value="10">10th</option>
                                    <option value="11">11th</option>
                                    <option value="12">12th</option>
                                </select>
                            </div>

                            <!-- 2 column grid layout for inline styling -->
                            <div class="row mb-2">
                                <div class="col d-flex justify-content-center">
                                    <!-- Checkbox -->
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" value="" id="form1Example3" checked />
                                        <label class="form-check-label" for="form1Example3">
                                            Remember me
                                        </label>
                                    </div>
                                </div>

                                <!-- <div class="col text-center">
                                    Simple link
                                    <a href="#!">Forgot password?</a>
                                </div> -->
                            </div>

                            <!-- Submit button -->
                            <button type="submit" class="btn btn-primary btn-block">sign up </button>
                            <hr>
                            <a href="loginstudent/loginstudent.php"><button type="button"  class="btn btn-success">login</button></a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

     </div>
    
<?php

unset($_SESSION['error']);
unset($_SESSION['input']);
?>


<?php include 'headerfoter/foter.php'; ?>

</body>
</html>
