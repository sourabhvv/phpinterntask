<!DOCTYPE html>
<html>
<head>
    <title>Indore School Department</title>
    <!-- Add Bootstrap CSS link -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Add Font Awesome CSS link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        /* Add your custom CSS styles for the footer here */
        footer {
            background-color: #f0f0f0;
            padding: 20px;
            text-align: center;
        }

        .footer-icons .icon {
            font-size: 24px;
            color: #333;
            margin: 5px;
        }

        .footer-text p {
            margin: 5px;
            color: #555;
        }
    </style>
</head>
<body>

<!-- Your page content goes here -->

<!-- Footer section -->
<footer>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 text-center">
                <div class="footer-icons">
                    <!-- Add your font icons here using <i> tags -->
                    <a href="#" class="icon"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" class="icon"><i class="fab fa-twitter"></i></a>
                    <a href="#" class="icon"><i class="fab fa-instagram"></i></a>
                    <a href="#" class="icon"><i class="fab fa-linkedin-in"></i></a>
                </div>
                <div class="footer-text">
                    <p>&copy; <?php echo date("Y"); ?> Indore School Department. All rights reserved.</p>
                    <p>Address: princess buissness park</p>
                    <p>Email: info@indoreschool.edu</p>
                </div>
            </div>
        </div>
    </div>
</footer>

<!-- Add Bootstrap JS and other scripts here -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
