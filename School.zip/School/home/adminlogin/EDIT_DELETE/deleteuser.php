<?php
session_start();

// check if user is authenticated
if (!isset($_SESSION['user'])) {
    header("Location: ./loginstudent.php");
    exit();
}

$servername = "localhost";
$username = "root";
$passworddb = "";
$dbname = "school";


$conn = new mysqli($servername, $username, $passworddb, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Delete the user based on the provided ID
    $sql = "DELETE FROM student WHERE id = '$id'";
    if ($conn->query($sql) === TRUE) {
        // Deletion successful, redirect to the dashboard or any other desired page
        header("Location: ./studentDash.php");
        exit();
    } else {
        // Error occurred during deletion
        echo "Error deleting user: " . $conn->error;
    }
} 

else {
    // ID parameter not set
    echo "Invalid request.";
}
?>
