<?php
session_start();

// check if user is authenticated
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

$servername = "localhost";
$username = "root";
$passworddb = "";
$dbname = "school";

// Create a new connection to taskdb
$conn = new mysqli($servername, $username, $passworddb, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the ID parameter is set
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    

    // Retrieve the user data based on the provided ID
    $sql = "SELECT * FROM student WHERE id = '$id' limit 1";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        // Display the edit form
        ?>

        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Edit User</title>
            <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css"
                  integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T"
                  crossorigin="anonymous">
        </head>
        <body>
        <div class="container">
            <h1>Edit User</h1>
            <form action="update.php" method="POST">
                <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                <div class="form-group">
                    <label for="fullname">Full Name</label>
                    <input type="text" class="form-control" id="fullname" name="name"
                           value="<?php echo $row['name']; ?>" required>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" id="email" name="email"
                           value="<?php echo $row['email']; ?>" required>
                </div>
                <div class="form-group">
                    <label for="rollno">Rollno</label>
                    <input type="text" class="form-control" id="rollno" name="rollno"
                           value="<?php echo $row['rollno']; ?>" required>
                </div>
                <div class="form-group">
                    <label for="contact">Contact</label>
                    <input type="text" class="form-control" id="contact" name="contact"
                           value="<?php echo $row['contact']; ?>" required>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" class="form-control" id="password" name="password"
                           value="<?php echo $row['password']; ?>" required>
                </div>
                <div class="form-group">
                    <label for="address">class</label>
                    <input type="text" class="form-control" id="address" name="class"
                           value="<?php echo $row['class']; ?>" required>
                </div>
                <button type="submit" class="btn btn-primary">Update</button>
            </form>
        </div>
        </body>
        </html>

        <?php
    } else {
        // User not found
        echo "User not found.";
    }
} else {
    // ID parameter not set

    echo $_GET['id'];
    echo "Invalid request.";
}
?>
