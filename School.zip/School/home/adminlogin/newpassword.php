<?php 
include '../headerfoter/headerfoter.php';
?>

<?php
session_start();

// Check if the user is logged in and has a valid email in the session
if (!isset($_SESSION['email'])) {
    header("Location: forgotpassword.php");
    exit();
}


function updatePassword($email, $newPassword)
{
    $servername = "localhost";
    $username = "root";
    $passwordDb = "";
    $dbname = "school";


    $conn = new mysqli($servername, $username, $passwordDb, $dbname);

    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    
    $hashedPassword = $newPassword;

   
    $stmt = $conn->prepare("UPDATE admin SET password = ? WHERE email = ?");
    $stmt->bind_param('ss', $hashedPassword, $email);
    $stmt->execute();

   
    $conn->close();
}


if ($_SERVER["REQUEST_METHOD"] === "POST") {
    
    if (isset($_POST['update_password'])) {
        $newPassword = $_POST['new_password'];
        $confirmNewPassword = $_POST['confirm_new_password'];

        
        if ($newPassword !== $confirmNewPassword) {
            $_SESSION['error'] = "Passwords do not match.";
            header("Location: newpassword.php");
            exit();
        }

        
        updatePassword($_SESSION['email'], $newPassword);

      
        header("Location: adminlogin.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Password</title>
    <!-- Add your CSS styles and Bootstrap if required -->
</head>

<body>
    <div class="container">
        <div id="intro" class="bg-image shadow-2-strong">
            <div class="mask d-flex align-items-center h-100vh" style="background-image:url('headerfoter/background.jpg')">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-xl-5 col-md-8">
                            <?php
                            // Display error messages, if any
                            if (isset($_SESSION['error'])) {
                                 echo '<div class="alert alert-danger">' . $_SESSION['error'] . '</div>';
                                unset($_SESSION['error']);
                            }
                            ?>
                            <form class="bg-white rounded-5 shadow-5-strong p-5" action="newpassword.php" method="post">
                                <h3>Update Password</h3>
                                <div class="form-outline mb-4">
                                    <label class="form-label" for="new_password">New Password</label>
                                    <input type="password" id="new_password" class="form-control" name="new_password" required />
                                </div>
                                <div class="form-outline mb-4">
                                    <label class="form-label" for="confirm_new_password">Confirm New Password</label>
                                    <input type="password" id="confirm_new_password" class="form-control" name="confirm_new_password" required />
                                </div>
                                <button type="submit" name="update_password" class="btn btn-primary btn-block">Update Password</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
<?php 
include '../headerfoter/foter.php';
?>