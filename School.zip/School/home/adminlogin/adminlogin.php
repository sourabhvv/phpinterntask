<?php 
session_start();

 if(isset($_SESSION['email']) && isset($_SESSION['error'])){
   $emailvalue  = $_SESSION['email'];
   $errorvalue  = $_SESSION['error'];
 }
 
 if ($_SERVER["REQUEST_METHOD"] === "POST")
 {
    header("location:resetform.php");
    exit();
 }

unset($_SESSION['email']);
unset($_SESSION['error']);
?>



<?php 
include '../headerfoter/headerfoter.php';
?>

    <div class="container">
        <div id="intro" class="bg-image shadow-2-strong">
            <div class="mask d-flex align-items-center h-100vh" style="background-image:url('headerfoter/background.jpg')">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-xl-5 col-md-8">

                            <form class="bg-white rounded-5 shadow-5-strong p-5" action="connectlogin.php" method="post">
                                <h3>admin login</h3>
                                
                                <!-- Email input -->
                                <div class="form-outline mb-4">
                                <label class="form-label" for="form3Example3">Email address</label>     
                                <input type="text" id="form3Example3" class="form-control" name="email" value="<?php 
                                       if(isset($emailvalue)){
                                echo $emailvalue;
                                     } ?>" />
                                </div>

                                <!-- Password input -->
                                <div class="form-outline mb-4">
                                    <label class="form-label" for="password">Password</label>
                                    <input type="password" id="form3Example4" class="form-control" name = "password" />
                                </div>

                                <!-- Remember me checkbox -->
                                <span style="color:red">
                                  <?php if(isset($errorvalue)){
                                       
                                        echo '<div class="form-check mb-4">
                                        
                                          <label class="form-check-label" for="form1Example3">
                                           <span style="color:red">incorrect password</span>

                                          <a href="forgotpassword.php"> forgot password</a>
                                        </label>
                                    </div>';
                                     }?>
                                </span> 
                                
                                
                                <!-- Submit button -->
                                <button type="submit" class="btn btn-primary btn-block">Sign In</button>
                                 <div class="back">
                                    <a href="../registration.php">back to home page</a>
                                 </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php 
include '../headerfoter/foter.php';
?>

