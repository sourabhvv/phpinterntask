<?php 
include '../headerfoter/headerfoter.php';
?>



<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/Exception.php';
require 'PHPMailer/SMTP.php';
// Function to send an email using PHPMailer
function sendEmail($recipientEmail, $subject, $message)
{
    // Instantiate PHPMailer
    $mail = new PHPMailer(true);

    try {
        // Set mailer to use SMTP
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'sourabhv945@gmail.com'; // Your Gmail email address
        $mail->Password = 'colxpxnxalwohgrd'; // Your Gmail password
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        // Set email format to HTML
        $mail->isHTML(true);

        // Set sender and recipient
        $mail->setFrom('sourabhv945@gmail.com', 'Your Name'); // Replace 'Your Name' with your name or organization name
        $mail->addAddress($recipientEmail);

        // Set email subject and content
        $mail->Subject = $subject;
        $mail->Body = $message;

        // Send the email
        $mail->send();
        return true;
    } catch (Exception $e) {
        return false;
    }
}

session_start();
// Check if the form was submitted (POST request)
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Check if the submitted form is for sending the OTP
    if (isset($_POST['send_otp'])) {
        // Implement the logic to generate and send the OTP to the user's email
        $email = $_POST['email']; // Get the email from the submitted form

        // Generate a 5-digit OTP
        $otp = mt_rand(10000, 99999);

        // Store the OTP in the session for verification later
        $_SESSION['otp'] = $otp;

        // Send the OTP to the user's email
        $subject = 'OTP for Password Reset';
        $message = "Your OTP for password reset is: $otp";

        if (sendEmail($email, $subject, $message)) {
            // Redirect to the same page with a success message
            header("location: forgotpassword.php?status=otp_sent&email=$email");
            exit();
        } else {
            // Redirect to the same page with an error message
            header("location: forgotpassword.php?status=email_error&email=$email");
            exit();
        }
    }




//Check if the submitted form is for verifying the OTP and updating the password
    if (isset($_POST['verify_otp'])) {
        // Get the inputted OTP and email from the form
        $input_otp = $_POST['otp'];
        $email = $_POST['email'];

        // Get the stored OTP from the session
        $stored_otp = isset($_SESSION['otp']) ? $_SESSION['otp'] : null;

        // Verify the inputted OTP with the stored OTP
        if ($input_otp == $stored_otp) {
            // OTP is valid, allow the user to input a new password
            $_SESSION['email'] = $email; // Store the email in the session to identify the user later
            header("location: newpassword.php");
            exit();
        } else {
            // Invalid OTP, redirect back to the same page with an error message
            header("location: forgotpassword.php?status=invalid_otp&email=$email");
            exit();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <!-- Add your CSS styles and Bootstrap if required -->
</head>

<body>
    <div class="container">
        <div id="intro" class="bg-image shadow-2-strong">
            <div class="mask d-flex align-items-center h-100vh" style="background-image:url('headerfoter/background.jpg')">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-xl-5 col-md-8">
                            <?php
                            // Display success or error messages
                            if (isset($_GET['status']) && $_GET['status'] == 'otp_sent') {
                                echo '<div class="alert alert-success">OTP sent to your email. Please check your email for the OTP.</div>';
                            } elseif (isset($_GET['status']) && $_GET['status'] == 'invalid_otp') {
                                echo '<div class="alert alert-danger">Invalid OTP. Please enter the correct OTP or request a new one.</div>';
                            }
                            ?>
                            <form class="bg-white rounded-5 shadow-5-strong p-5" action="forgotpassword.php" method="post">
                                <h3>Forgot Password</h3>
                                <div class="form-outline mb-4">
                                    <label class="form-label" for="form3Example3">Email address</label>
                                    <input type="email" id="form3Example3" class="form-control" name="email" required />
                                </div>
                                <button type="submit" name="send_otp" class="btn btn-primary btn-block">Send OTP</button>
                            </form>

                            <form class="bg-white rounded-5 shadow-5-strong p-5" action="forgotpassword.php" method="post">
                                <h3>Verify OTP and Reset Password</h3>
                                <div class="form-outline mb-4">
                                    <label class="form-label" for="otp">Enter OTP</label>
                                    <input type="text" id="otp" class="form-control" name="otp" required />
                                </div>
                                <input type="hidden" name="email" value="<?php echo isset($_GET['email']) ? $_GET['email'] : ''; ?>" />
                                <button type="submit" name="verify_otp" class="btn btn-primary btn-block">Verify OTP and Reset Password</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>

<?php 
include '../headerfoter/foter.php';
?>