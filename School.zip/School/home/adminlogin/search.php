<?php
session_start();

include 'connection.php';

if (isset($_POST['searchValue'])) {
    $searchValue = $_POST['searchValue'];
    $date = $_POST['date'];

    $sql = "SELECT * FROM student WHERE name LIKE '%$searchValue%' OR rollno LIKE '%$searchValue%' OR  email LIKE '%$searchValue%' AND date LIKE '$date'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo '<tr>';
            echo '<td>' . $row['id'] . '</td>';
            echo '<td>' . $row['name'] . '</td>';
            echo '<td>' . $row['rollno'] . '</td>';
            echo '<td>' . $row['email'] . '</td>';
            echo '<td>' . $row['contact'] . '</td>';
            echo '<td>' . $row['password'] . '</td>';
            echo '<td>' . $row['class'] . '</td>';
            echo '<td>' . $row['date'] . '</td>';
            echo '<td>';
            echo '<a href="EDIT_DELETE/edit.php?id=' . $row['id'] . '">';
            echo '<button type="button" class="btn btn-dark">Edit</button>';
            echo '</a>';
            echo '<button type="button" class="btn btn-danger deleteRowBtn" data-id="' . $row['id'] . '">Delete</button>';
            echo '</td>';
            echo '</tr>';
        }
    } else {
        
        echo '<tr><td colspan="8">No results found.</td></tr>';
    }
}


