<?php
session_start();

// Destroy all session data
session_destroy();

// Redirect user back to the login page
header("Location: loginstudent.php");
exit();
?>