<?php 
include '../headerfoter/headerstudent.php';
?>


<?php
session_start();

// check if user is authenticated
if (!isset($_SESSION['user'])) {
    header("Location: loginstudent.php");
    exit();
}

$servername = "localhost";
$username = "root";
$passworddb = "";
$dbname = "school";

// Create a new connection to the database
$conn = new mysqli($servername, $username, $passworddb, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$useremail = $_SESSION['user']['email'];

// check if the user search for data
if (isset($_SESSION['search_results']) && !empty($_SESSION['search_results'])) {
    // Use search results
    $results = $_SESSION['search_results'];
} else {
    $sql = "SELECT * FROM student where email = '$useremail'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Fetch all records and store them in $results
        $results = $result->fetch_all(MYSQLI_ASSOC);
    } else {
        $results = array(); // No records found, initialize $results as an empty array
    }
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Panel</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css">
    <link rel="stylesheet" href="style.css">
    <style>
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 6px;
            background-color: #fff;
            color: black;
        }

        .navbar-item {
            margin-left: 10px;
            color: #fff;
            text-decoration: none;
        }

        .navbar-item:hover {
            color: #fff;
            text-decoration: underline;
        }

        .container {
            padding: 20px;
        }

        .table {
            margin-bottom: 1rem;
            color: #212529;
        }

        .table thead th {
            vertical-align: bottom;
            border-bottom: 2px solid #dee2e6;
        }

        .table tbody+tbody {
            border-top: 2px solid #dee2e6;
        }

        .table .thead-dark th {
            color: #fff;
            background-color: #343a40;
            border-color: #454d55;
        }

        .table td,
        .table th {
            padding: 0.75rem;
            vertical-align: top;
            border-top: 1px solid #dee2e6;
        }

        .logout {
            margin-right: 0;
        }

        .table-wrapper {
            max-height: 400px;
            /* Adjust the height based on your requirements */
            overflow-y: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        thead th {
            background-color: #f2f2f2;
        }

        .search {
            width: 400px;
        }

        .date {
            margin-left: 300px;
            width: 400px;
        }

        .topsearchbar {
            display: flex;
        }

 
    </style>
</head>

<body>
    <div class="navbar">
        <div class="navbar-container">
        <div class="logout">
                <form action="logoutStudent.php" method="post">
                    <button type="submit" class="btn btn-danger">Logout</button>
                </form>
        </div>
            <a href="#" class="navbar-item">
                <h2>hello student <?php echo $_SESSION['user']['email']; ?></h2>
            </a>
            
        </div>
    </div>

    <div class="container">
        <table>
            <thead class="thead-dark">
                <tr>
                    <div class="topsearchbar">
                        
                       
                    </div>
                </tr>
                <tr>
                    <th>ID</th>
                    <th>Fullname</th>
                    <th>student rollno</th>
                    <th>emailt</th>
                    <th>contact</th>
                    <th>password</th>
                    <th>class</th>
                    <th>date</th>
                    <th>Edit/Delete</th>
                </tr>
            </thead>
        </table>
        <div class="table-wrapper">
    <table class="table">
        <tbody>
            <?php foreach ($results as $row) { ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['rollno']; ?></td>
                    <td><?php echo $row['email']; ?></td>
                    <td><?php echo $row['contact']; ?></td>
                    <td><?php echo $row['password']; ?></td>
                    <td><?php echo $row['class']; ?></td>
                    <td><?php echo $row['date']; ?></td>
                    <td>
                        <a href="EDIT_DELETE/edit.php?id=<?php echo $row['id']; ?>">
                            <button type="button" class="btn btn-dark">Edit</button>
                        </a>
                        <button type="button" class="btn btn-danger deleteRowBtn" data-id="<?php echo $row['id']; ?>">Delete</button>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>

      <script>
      $(document).ready(function() {
    // for date input
    $('#Customization').datepicker({
        startdate:new Date(),
                format: 'yyyy-mm-dd', // Specify the desired date format
                autoclose: true
            });
           
      //  added event in date       
     $('#Customization').on('change', function() {
                
                var value = $(this).val();

            // Filter table rows based on the selected date stor both value in a single variable
               //searchTable('date',value);
            });        

    
       
    // Add event listener to the search input field
    $('#searchInput').on('keyup', function() {
        var date_val=$('#Customization').val()
        var value = $(this).val().toLowerCase();

        // Filter table rows based on the entered fullname using Ajax
        // searchTable('input',value,date_val);
    });

    // Add click event listener to the search button iski koi jarurat nahi ha
    $('#searchbtn').on('click', function() {
        console.log("hello");
        var date_val=$('#Customization').val()
        var value = $('#searchInput').val().toLowerCase();

        // Filter table rows based on the entered fullname using Ajax
        searchTable(value,date_val);
    });

    // Function to perform the Ajax request
    function searchTable(value,dates) {
        $.ajax({
            url: 'search.php', 
            type: 'POST',
            data: {
                
                'searchValue': value,
                'date':dates
            },
            dataType: 'html',

            success: function(response) {
                // Update the table body with the filtered rows
                console.log(response)
                $('table tbody').html(response);
            },
            error: function(xhr, status, error) {
                console.error(error);
            }
        });
    }

   // implement delete function 
   $('.deleteRowBtn').on('click',function(){
    var rowID = $(this).data('id');
    confirmDelete(rowID);
   });
   
   function confirmDelete(rowID){
    if (confirm('Are you sure you want to delete this row?')) {
                    deleteRow(rowID);
    }
   }
   function deleteRow(rowID){
    $.ajax({
          url:'deleteuser.php',
          type:'GET',
          data:{
             Id:rowID
          },
          success:function(response){
            if(response.success){
                $('tr[data-id="' + rowID + '"]').remove();
            }
          },
          error: function(xhr, status, error) {
                        console.error(error);
          }
    });
   } 
 
});

</script>

</body>

</html>


<?php 
include '../headerfoter/foter.php';
?>
