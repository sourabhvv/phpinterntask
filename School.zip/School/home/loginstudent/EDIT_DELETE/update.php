<?php 
session_start();

// Check if user is authenticated
if (!isset($_SESSION['user'])) {
    header("location:  ../studentDash.php");
    exit();
}

// Establish database connection
$servername = "localhost";
$username = "root";
$passworddb = "";
$dbname = "school";

$conn = new mysqli($servername, $username, $passworddb, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the form data
    $id = $_POST['id'];
    $fullname = $_POST['fullname'];
    $email = $_POST['email'];
    $contact = $_POST['contact'];
    $password = $_POST['password'];
    $address = $_POST['address'];

    // Update the data
    $stmt = $conn->prepare("UPDATE student SET fullname=?, emaildb=?, contact=?, password=?, address=? WHERE id=?");
    $stmt->bind_param("sssssi", $fullname, $email, $contact, $password, $address, $id);

    if ($stmt->execute()) {
        // Successful update, redirect to the dashboard or any other desired page
        header("location: ../Dashboard.php");
        exit();
    } else {
        // Error occurred during update
        echo "Error updating user: " . $conn->error;
    }
} else {
    // Invalid request
    echo "Invalid request.";
}
?>
